import os,json,csv,time,io,zipfile,xml.etree.ElementTree as ET
from pathlib import Path
import requests
ROOT=Path(__file__).parent
CFG=json.loads((ROOT/'config.json').read_text(encoding='utf-8'))
BASE='https://opendart.fss.or.kr/api/'
KEY=os.environ.get('DART_API_KEY','')
S=requests.Session()
def api(endpoint,params):
 for attempt in range(5):
  try:
   r=S.get(BASE+endpoint,params={'crtfc_key':KEY,**params},timeout=60);r.raise_for_status()
   if endpoint.endswith('.json'):
    data=r.json();status=data.get('status')
    if status=='013':return {}
    if status!='000':raise RuntimeError(f'{endpoint}: {status} {data.get("message")}')
    return data
   return r.content
  except (requests.RequestException,RuntimeError):
   if attempt==4:raise
   time.sleep(2**attempt)
def corp_code():
 raw=api('corpCode.xml',{})
 with zipfile.ZipFile(io.BytesIO(raw)) as z:xml=z.read(z.namelist()[0])
 for c in ET.fromstring(xml).findall('list'):
  if c.findtext('stock_code','').strip()==CFG['stock_code']:return c.findtext('corp_code')
 raise RuntimeError('기업 고유번호를 찾지 못했습니다')
FIELDS={'매출액':'revenue','영업이익':'operating_profit','당기순이익':'net_income','자산총계':'assets','부채총계':'liabilities','자본총계':'equity','유동자산':'current_assets','유동부채':'current_liabilities','현금및현금성자산':'cash','영업활동현금흐름':'operating_cash_flow','영업활동으로인한현금흐름':'operating_cash_flow','투자활동현금흐름':'investing_cash_flow','재무활동현금흐름':'financing_cash_flow'}
ALIASES={'수익(매출액)':'revenue','매출':'revenue','영업손익':'operating_profit','당기순손익':'net_income','현금및현금성자산':'cash'}
def number(x):
 try:return int(str(x).replace(',',''))
 except (ValueError,TypeError):return None
def ratio(a,b):return round(a/b*100,2) if a is not None and b not in (None,0) else None
def extract(items,year,code):
 rows={}
 for item in items:
  if item.get('reprt_code')!=code or str(item.get('bsns_year'))!=str(year):continue
  if item.get('fs_div') not in ('CFS','OFS'):continue
  label=item.get('account_nm','').replace(' ','')
  key=FIELDS.get(label) or ALIASES.get(label)
  if not key:continue
  stmt=item.get('sj_div')
  if key in ('assets','liabilities','equity','current_assets','current_liabilities','cash') and stmt!='BS':continue
  if key in ('revenue','operating_profit','net_income') and stmt not in ('IS','CIS'):continue
  if key.endswith('cash_flow') and stmt!='CF':continue
  val=number(item.get('thstrm_amount'))
  if val is None:continue
  group=item['fs_div']; rows.setdefault(group,{})
  # Prefer standardized IFRS IDs when duplicate account labels exist
  old=rows[group].get(key)
  if old is None or item.get('account_id','').startswith(('ifrs','ifrs-full')):rows[group][key]=val
 return rows.get('CFS') or rows.get('OFS') or {}
def main():
 if not KEY:raise SystemExit('DART_API_KEY 환경변수를 설정하세요')
 from datetime import datetime
 from zoneinfo import ZoneInfo
 year_now=datetime.now(ZoneInfo('Asia/Seoul')).year
 corp=corp_code(); records=[]
 for year in range(CFG['start_year'],year_now+1):
  for code,kind in [('11013','Q1'),('11012','H1'),('11014','Q3'),('FY')]:
   if code=='FY':code='11011'
   try:
    data=api('fnlttSinglAcntAll.json',{'corp_code':corp,'bsns_year':year,'reprt_code':code,'fs_div':'CFS'})
    items=data.get('list',[])
    if not items:
     data=api('fnlttSinglAcntAll.json',{'corp_code':corp,'bsns_year':year,'reprt_code':code,'fs_div':'OFS'})
     items=data.get('list',[])
    d=extract(items,year,code)
    if not d:continue
    d.update(year=year,period=kind,report_code=code,statement_basis='CFS' if any(x.get('fs_div')=='CFS' for x in items) else 'OFS')
    records.append(d)
   except Exception as exc:print(f'WARN {year} {kind}: {exc}',flush=True)
   time.sleep(.12)
 # Flow statements are year-to-date; convert Q2/Q3/Q4 by subtraction only when matching basis is available
 lookup={(r['year'],r['period']):r for r in records}
 flows=['revenue','operating_profit','net_income','operating_cash_flow','investing_cash_flow','financing_cash_flow']
 quarters=[]
 for r in records:
  prev={'Q1':None,'H1':'Q1','Q3':'H1','FY':'Q3'}[r['period']]
  q=dict(r);q['period']={'Q1':'Q1','H1':'Q2','Q3':'Q3','FY':'Q4'}[r['period']]
  prior=lookup.get((r['year'],prev)) if prev else None
  for k in flows:
   if prev:
    q[k]=r[k]-prior[k] if prior and r.get(k) is not None and prior.get(k) is not None and r['statement_basis']==prior['statement_basis'] else None
  quarters.append(q)
 for r in records+quarters:
  r['operating_margin']=ratio(r.get('operating_profit'),r.get('revenue'))
  r['net_margin']=ratio(r.get('net_income'),r.get('revenue'))
  r['debt_ratio']=ratio(r.get('liabilities'),r.get('equity'))
  r['current_ratio']=ratio(r.get('current_assets'),r.get('current_liabilities'))
  r['roa']=ratio(r.get('net_income'),r.get('assets')) if r['period']=='FY' else None
  r['roe']=ratio(r.get('net_income'),r.get('equity')) if r['period']=='FY' else None
 output={'company':CFG['company'],'stock_code':CFG['stock_code'],'updated_at':datetime.now(ZoneInfo('Asia/Seoul')).isoformat(),'annual':[r for r in records if r['period']=='FY'],'half_year':[r for r in records if r['period']=='H1'],'quarterly':quarters,'cumulative':[r for r in records if r['period'] in ('Q1','Q3')]}
 out=ROOT/'docs'/'data.json';out.parent.mkdir(exist_ok=True);out.write_text(json.dumps(output,ensure_ascii=False,indent=2),encoding='utf-8')
 print(f'Saved {len(records)} reports and {len(quarters)} quarter rows')
if __name__=='__main__':main()
