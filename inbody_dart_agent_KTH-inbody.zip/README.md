[![🔗 대시보드 바로가기](https://img.shields.io/badge/%F0%9F%94%97-%EB%8C%80%EC%8B%9C%EB%B3%B4%EB%93%9C_%EB%B0%94%EB%A1%9C%EA%B0%80%EA%B8%B0-149e95?style=for-the-badge)](https://hsc-class01.github.io/KTH-inbody/)

# 인바디 DART Financial Agent

OpenDART 재무정보를 2010년부터 가능한 범위에서 수집하여 GitHub Pages 대시보드에 표시합니다.

## 시작하기
1. ZIP을 압축 해제하고 **숨김 항목 표시**를 켜서 `.github/workflows/update.yml`을 포함한 파일 전체를 저장소 최상위에 업로드합니다. ZIP 내부에는 `.github` 외에 숨김 파일이 없습니다. GitHub Actions 예약 실행에는 `.github/workflows`가 반드시 필요합니다.
2. GitHub 저장소 Settings → Secrets and variables → Actions → New repository secret → 이름 `DART_API_KEY`, 값은 OpenDART에서 발급한 API 키를 입력합니다. 코드에 키를 직접 넣지 마세요.
3. Settings → Actions → General → Workflow permissions에서 **Read and write permissions**를 허용합니다. 조직 정책에 따라 제한될 수 있습니다.
4. Actions → Update DART financials → Run workflow를 눌러 최초 실행합니다.
5. Settings → Pages → Build and deployment → Deploy from a branch → `main` / `/docs` → Save.
6. README 최상단 배지의 배지 링크는 이 저장소의 주소로 설정되어 있습니다.
7. 저장소 오른쪽 About → 톱니바퀴 → Website에 `https://hsc-class01.github.io/KTH-inbody/` 입력 후 저장합니다. 이는 저장소 소유자가 직접 설정해야 합니다.

**예약 시간**: UTC 매월 28~31일 15:00에 트리거를 확인하고, 한국시간 1일 00:00인 경우에만 실행합니다. GitHub Actions 스케줄은 지연될 수 있습니다.

## 데이터 설명
- Annual: 사업보고서 FY, Half-year: 반기보고서 H1(누적), Quarterly: 각 분기 단독 손익/현금흐름, 재무상태표는 시점 값.
- API 미제공·보고서 미제출·표준 계정명 차이 등으로 일부 값은 누락될 수 있습니다. 2010년부터 모든 연도/항목의 확보를 보장하지 않습니다.
- 연간 ROE/ROA는 당기순이익을 기말 자본/자산으로 나눈 단순 비율이며 평균잔액 기준이 아닙니다.
- 자료를 받지 못한 기간의 수치는 만들어내지 않습니다.

## 국내 Peer Firms (사업 유사성 참고)
| 기업 | 종목코드 | 비교 분야 | 한계 |
|---|---|---|---|
| 셀바스헬스케어 | 208370 | 건강 측정·의료기기 | 사업 구조 상이 |
| 비스토스 | 419540 | 생체신호 의료기기 | 체성분 분석 중심 아님 |
| 휴비츠 | 065510 | 진단·측정 의료기기 | 안과 중심 |

Peer 기업 재무정보는 본 버전에서 자동 수집하지 않으며, 비교 후보 목록만 표시합니다.
